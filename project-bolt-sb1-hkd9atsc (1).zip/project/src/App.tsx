import React, { useState } from 'react';
import { Globe2, Heart, Shield, ScrollText, ChevronDown, MapPin, AlertTriangle, X, Camera, Map, Calendar, Utensils, Plane, Hotel, TreePine, Users, MessageCircle, Book, Users2, Landmark, PartyPopper, DollarSign, Shirt, Coffee } from 'lucide-react';
import { Dialog } from '@headlessui/react';

function App() {
  const [isLearnMoreOpen, setIsLearnMoreOpen] = useState(false);
  const [selectedCulturalTab, setSelectedCulturalTab] = useState('norms');

  const culturalTabs = [
    { id: 'norms', label: 'Cultural Norms', icon: Book },
    { id: 'dos', label: "Do's & Don'ts", icon: Shield },
    { id: 'communication', label: 'Communication', icon: MessageCircle },
    { id: 'religion', label: 'Religion', icon: Landmark },
    { id: 'social', label: 'Social Structure', icon: Users2 },
    { id: 'festivals', label: 'Festivals', icon: PartyPopper },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="relative h-[70vh] bg-cover bg-center" style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1488085061387-422e29b40080?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80")'
      }}>
        <div className="absolute inset-0 bg-black bg-opacity-50" />
        <div className="relative h-full flex items-center justify-center text-center px-4">
          <div className="max-w-4xl">
            <h1 className="text-5xl font-bold text-white mb-6">Safe and Informed Travel</h1>
            <p className="text-xl text-white mb-8">Your comprehensive guide to cultural awareness, health safety, and scam prevention while traveling</p>
            <button 
              onClick={() => setIsLearnMoreOpen(true)}
              className="bg-white text-gray-900 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors flex items-center gap-2"
            >
              Learn More
              <ChevronDown size={20} />
            </button>
          </div>
        </div>
      </header>

      {/* Learn More Modal */}
      <Dialog
        open={isLearnMoreOpen}
        onClose={() => setIsLearnMoreOpen(false)}
        className="relative z-50"
      >
        <div className="fixed inset-0 bg-black/30" aria-hidden="true" />
        <div className="fixed inset-0 flex items-center justify-center p-4">
          <Dialog.Panel className="mx-auto max-w-4xl bg-white rounded-2xl p-8 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-6">
              <Dialog.Title className="text-3xl font-bold">Travel Guide & Resources</Dialog.Title>
              <button
                onClick={() => setIsLearnMoreOpen(false)}
                className="p-2 hover:bg-gray-100 rounded-full"
              >
                <X size={24} />
              </button>
            </div>

            <div className="space-y-8">
              {/* About the Destination */}
              <section>
                <h3 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                  <Globe2 className="text-blue-600" />
                  About the Destination
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-2">History & Culture</h4>
                    <p className="text-gray-600">Explore rich cultural heritage and historical landmarks.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Local Traditions</h4>
                    <p className="text-gray-600">Experience authentic festivals and cultural celebrations.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Climate Guide</h4>
                    <p className="text-gray-600">Best seasons to visit and weather information.</p>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Local Cuisine</h4>
                    <p className="text-gray-600">Must-try dishes and dining recommendations.</p>
                  </div>
                </div>
              </section>

              {/* Cultural Norms Section */}
              <section>
                <h3 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                  <Book className="text-blue-600" />
                  Cultural Norms & Etiquette
                </h3>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-blue-50 p-6 rounded-lg">
                    <div className="flex items-center gap-2 mb-4">
                      <Users className="text-blue-600" />
                      <h4 className="font-semibold">Greeting Customs</h4>
                    </div>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Traditional greetings</li>
                      <li>• Physical contact norms</li>
                      <li>• Formal vs casual settings</li>
                    </ul>
                  </div>
                  <div className="bg-green-50 p-6 rounded-lg">
                    <div className="flex items-center gap-2 mb-4">
                      <Shirt className="text-green-600" />
                      <h4 className="font-semibold">Dress Codes</h4>
                    </div>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Religious sites</li>
                      <li>• Public places</li>
                      <li>• Special occasions</li>
                    </ul>
                  </div>
                  <div className="bg-purple-50 p-6 rounded-lg">
                    <div className="flex items-center gap-2 mb-4">
                      <Coffee className="text-purple-600" />
                      <h4 className="font-semibold">Dining Etiquette</h4>
                    </div>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Table manners</li>
                      <li>• Meal customs</li>
                      <li>• Tipping practices</li>
                    </ul>
                  </div>
                </div>
              </section>

              {/* Do's and Don'ts */}
              <section>
                <h3 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                  <Shield className="text-blue-600" />
                  Cultural Do's & Don'ts
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-green-50 p-6 rounded-lg">
                    <h4 className="font-semibold mb-4 text-green-700">Recommended Behaviors</h4>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <div className="mt-1 text-green-600">•</div>
                        <p>Learn basic local phrases</p>
                      </li>
                      <li className="flex items-start gap-2">
                        <div className="mt-1 text-green-600">•</div>
                        <p>Respect religious customs</p>
                      </li>
                      <li className="flex items-start gap-2">
                        <div className="mt-1 text-green-600">•</div>
                        <p>Follow local dress codes</p>
                      </li>
                    </ul>
                  </div>
                  <div className="bg-red-50 p-6 rounded-lg">
                    <h4 className="font-semibold mb-4 text-red-700">Behaviors to Avoid</h4>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <div className="mt-1 text-red-600">•</div>
                        <p>Public displays of affection</p>
                      </li>
                      <li className="flex items-start gap-2">
                        <div className="mt-1 text-red-600">•</div>
                        <p>Sensitive conversation topics</p>
                      </li>
                      <li className="flex items-start gap-2">
                        <div className="mt-1 text-red-600">•</div>
                        <p>Disrespecting local customs</p>
                      </li>
                    </ul>
                  </div>
                </div>
              </section>

              {/* Communication Styles */}
              <section>
                <h3 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                  <MessageCircle className="text-blue-600" />
                  Communication Guidelines
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-4">Verbal Communication</h4>
                    <div className="space-y-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h5 className="font-semibold mb-2">Formal vs Informal</h5>
                        <p className="text-gray-600">Understanding when to use different levels of formality</p>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h5 className="font-semibold mb-2">Common Phrases</h5>
                        <p className="text-gray-600">Essential local expressions and their meanings</p>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-4">Non-verbal Communication</h4>
                    <div className="space-y-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h5 className="font-semibold mb-2">Body Language</h5>
                        <p className="text-gray-600">Understanding gestures and personal space</p>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h5 className="font-semibold mb-2">Time Perception</h5>
                        <p className="text-gray-600">Cultural views on punctuality and scheduling</p>
                      </div>
                    </div>
                  </div>
                </div>
              </section>

              {/* Religion and Beliefs */}
              <section>
                <h3 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                  <Landmark className="text-blue-600" />
                  Religious Practices
                </h3>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <img
                      src="https://images.unsplash.com/photo-1493809842364-78817add7ffb?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                      alt="Religious site"
                      className="rounded-lg mb-4"
                    />
                    <h4 className="text-xl font-semibold mb-2">Sacred Sites</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Dress code requirements</li>
                      <li>• Photography rules</li>
                      <li>• Visiting hours</li>
                    </ul>
                  </div>
                  <div className="space-y-4">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Major Religions</h4>
                      <p className="text-gray-600">Overview of dominant faiths and their practices</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Religious Festivals</h4>
                      <p className="text-gray-600">Important dates and celebrations</p>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold mb-2">Dietary Guidelines</h4>
                      <p className="text-gray-600">Religious food restrictions and customs</p>
                    </div>
                  </div>
                </div>
              </section>

              {/* Social Structure */}
              <section>
                <h3 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                  <Users2 className="text-blue-600" />
                  Social Structure
                </h3>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-blue-50 p-6 rounded-lg">
                    <h4 className="font-semibold mb-4">Family Dynamics</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Traditional roles</li>
                      <li>• Generational respect</li>
                      <li>• Family celebrations</li>
                    </ul>
                  </div>
                  <div className="bg-purple-50 p-6 rounded-lg">
                    <h4 className="font-semibold mb-4">Authority & Respect</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Age-based hierarchy</li>
                      <li>• Professional titles</li>
                      <li>• Social status</li>
                    </ul>
                  </div>
                  <div className="bg-green-50 p-6 rounded-lg">
                    <h4 className="font-semibold mb-4">Marriage & Relationships</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Traditional customs</li>
                      <li>• Modern practices</li>
                      <li>• Social expectations</li>
                    </ul>
                  </div>
                </div>
              </section>

              {/* Festivals and Celebrations */}
              <section>
                <h3 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                  <PartyPopper className="text-blue-600" />
                  Festivals & Celebrations
                </h3>
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <img
                        src="https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                        alt="Festival celebration"
                        className="rounded-lg mb-4"
                      />
                      <h4 className="text-xl font-semibold mb-2">Major Festivals</h4>
                      <p className="text-gray-600">Annual celebrations and their cultural significance</p>
                    </div>
                    <div className="space-y-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Traditional Attire</h4>
                        <p className="text-gray-600">Cultural clothing and their meanings</p>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Festival Foods</h4>
                        <p className="text-gray-600">Special dishes and their significance</p>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold mb-2">Public Holidays</h4>
                        <p className="text-gray-600">Important dates and celebrations</p>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            </div>
          </Dialog.Panel>
        </div>
      </Dialog>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-16">
        {/* Key Features */}
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          <div className="bg-gray-50 p-8 rounded-xl">
            <Globe2 className="w-12 h-12 text-blue-600 mb-4" />
            <h2 className="text-2xl font-bold mb-4">Cultural Differences</h2>
            <p className="text-gray-600">Understanding and respecting local customs, traditions, and etiquette across different cultures.</p>
          </div>
          <div className="bg-gray-50 p-8 rounded-xl">
            <Heart className="w-12 h-12 text-red-600 mb-4" />
            <h2 className="text-2xl font-bold mb-4">Health Issues</h2>
            <p className="text-gray-600">Essential health information, vaccination requirements, and medical facilities in different regions.</p>
          </div>
          <div className="bg-gray-50 p-8 rounded-xl">
            <Shield className="w-12 h-12 text-green-600 mb-4" />
            <h2 className="text-2xl font-bold mb-4">Scam Prevention</h2>
            <p className="text-gray-600">Stay informed about common tourist scams and learn how to protect yourself while traveling.</p>
          </div>
        </div>

        {/* Cultural Differences Section */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold mb-12 text-center">Understanding Cultural Differences</h2>
          
          {/* Cultural Navigation Tabs */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {culturalTabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setSelectedCulturalTab(tab.id)}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full transition-colors ${
                    selectedCulturalTab === tab.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 hover:bg-gray-200'
                  }`}
                >
                  <Icon size={20} />
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Cultural Content Sections */}
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            {/* Norms and Etiquette */}
            {selectedCulturalTab === 'norms' && (
              <div className="p-8">
                <h3 className="text-2xl font-bold mb-6">Cultural Norms & Etiquette</h3>
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <img
                      src="https://images.unsplash.com/photo-1577791465485-b80039b4d69a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                      alt="Traditional greeting"
                      className="rounded-lg mb-4"
                    />
                    <h4 className="text-xl font-semibold mb-4">Greeting Customs</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Learn traditional greetings and their significance</li>
                      <li>• Understand appropriate physical contact norms</li>
                      <li>• Master formal vs informal greeting situations</li>
                    </ul>
                  </div>
                  <div>
                    <img
                      src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                      alt="Dining etiquette"
                      className="rounded-lg mb-4"
                    />
                    <h4 className="text-xl font-semibold mb-4">Dining Etiquette</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Table manners and customs</li>
                      <li>• Using local eating utensils</li>
                      <li>• Meal timing and social aspects</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* Do's and Don'ts */}
            {selectedCulturalTab === 'dos' && (
              <div className="p-8">
                <h3 className="text-2xl font-bold mb-6">Do's & Don'ts</h3>
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="bg-green-50 p-6 rounded-lg">
                    <h4 className="text-xl font-semibold mb-4 text-green-700">Do's</h4>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-2">
                        <div className="mt-1 text-green-600">•</div>
                        <p>Research local customs before visiting</p>
                      </li>
                      <li className="flex items-start gap-2">
                        <div className="mt-1 text-green-600">•</div>
                        <p>Dress appropriately for different settings</p>
                      </li>
                      <li className="flex items-start gap-2">
                        <div className="mt-1 text-green-600">•</div>
                        <p>Learn basic local phrases</p>
                      </li>
                    </ul>
                  </div>
                  <div className="bg-red-50 p-6 rounded-lg">
                    <h4 className="text-xl font-semibold mb-4 text-red-700">Don'ts</h4>
                    <ul className="space-y-3">
                      <li className="flex items-start gap-2">
                        <div className="mt-1 text-red-600">•</div>
                        <p>Disrespect local traditions</p>
                      </li>
                      <li className="flex items-start gap-2">
                        <div className="mt-1 text-red-600">•</div>
                        <p>Take photos without permission</p>
                      </li>
                      <li className="flex items-start gap-2">
                        <div className="mt-1 text-red-600">•</div>
                        <p>Ignore dress codes at religious sites</p>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* Communication Styles */}
            {selectedCulturalTab === 'communication' && (
              <div className="p-8">
                <h3 className="text-2xl font-bold mb-6">Communication Styles</h3>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="bg-blue-50 p-6 rounded-lg">
                    <h4 className="text-xl font-semibold mb-4">Verbal Communication</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Tone and volume</li>
                      <li>• Direct vs indirect speech</li>
                      <li>• Common phrases</li>
                    </ul>
                  </div>
                  <div className="bg-purple-50 p-6 rounded-lg">
                    <h4 className="text-xl font-semibold mb-4">Body Language</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Personal space</li>
                      <li>• Eye contact norms</li>
                      <li>• Gesture meanings</li>
                    </ul>
                  </div>
                  <div className="bg-yellow-50 p-6 rounded-lg">
                    <h4 className="text-xl font-semibold mb-4">Time Perception</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Punctuality expectations</li>
                      <li>• Meeting customs</li>
                      <li>• Schedule flexibility</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* Religion and Beliefs */}
            {selectedCulturalTab === 'religion' && (
              <div className="p-8">
                <h3 className="text-2xl font-bold mb-6">Religion & Beliefs</h3>
                <div className="grid md:grid-cols-2 gap-8">
                  <div>
                    <img
                      src="https://images.unsplash.com/photo-1493809842364-78817add7ffb?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                      alt="Religious site"
                      className="rounded-lg mb-4"
                    />
                    <h4 className="text-xl font-semibold mb-4">Sacred Sites</h4>
                    <ul className="space-y-2 text-gray-600">
                      <li>• Dress code requirements</li>
                      <li>• Visiting hours and protocols</li>
                      <li>• Photography restrictions</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold mb-4">Religious Practices</h4>
                    <div className="space-y-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h5 className="font-semibold mb-2">Daily Rituals</h5>
                        <p className="text-gray-600">Understanding prayer times and religious observances</p>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h5 className="font-semibold mb-2">Holy Days</h5>
                        <p className="text-gray-600">Major religious festivals and celebrations</p>
                      </div>
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h5 className="font-semibold mb-2">Dietary Restrictions</h5>
                        <p className="text-gray-600">Food and drink considerations</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Social Structures */}
            {selectedCulturalTab === 'social' && (
              <div className="p-8">
                <h3 className="text-2xl font-bold mb-6">Social Structure & Relationships</h3>
                <div className="grid md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="bg-gray-50 p-6 rounded-lg">
                      <h4 className="text-xl font-semibold mb-4">Family Dynamics</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li>• Multi-generational households</li>
                        <li>• Role of elders</li>
                        <li>• Family celebrations</li>
                      </ul>
                    </div>
                    <div className="bg-gray-50 p-6 rounded-lg">
                      <h4 className="text-xl font-semibold mb-4">Social Hierarchy</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li>• Age and status respect</li>
                        <li>• Professional relationships</li>
                        <li>• Community leadership</li>
                      </ul>
                    </div>
                  </div>
                  <div>
                    <img
                      src="https://images.unsplash.com/photo-1511632765486-a01980e01a18?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                      alt="Family gathering"
                      className="rounded-lg mb-4"
                    />
                    <h4 className="text-xl font-semibold mb-4">Modern vs Traditional</h4>
                    <p className="text-gray-600">Understanding the balance between traditional values and modern lifestyle in different societies.</p>
                  </div>
                </div>
              </div>
            )}

            {/* Festivals and Celebrations */}
            {selectedCulturalTab === 'festivals' && (
              <div className="p-8">
                <h3 className="text-2xl font-bold mb-6">Festivals & Celebrations</h3>
                <div className="space-y-8">
                  <div className="grid md:grid-cols-3 gap-6">
                    <div className="bg-orange-50 p-6 rounded-lg">
                      <h4 className="text-xl font-semibold mb-4">Traditional Festivals</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li>• Annual celebrations</li>
                        <li>• Cultural significance</li>
                        <li>• Visitor participation</li>
                      </ul>
                    </div>
                    <div className="bg-green-50 p-6 rounded-lg">
                      <h4 className="text-xl font-semibold mb-4">Seasonal Events</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li>• Harvest festivals</li>
                        <li>• Weather celebrations</li>
                        <li>• Cultural performances</li>
                      </ul>
                    </div>
                    <div className="bg-blue-50 p-6 rounded-lg">
                      <h4 className="text-xl font-semibold mb-4">Modern Celebrations</h4>
                      <ul className="space-y-2 text-gray-600">
                        <li>• Contemporary events</li>
                        <li>• Music festivals</li>
                        <li>• Food festivals</li>
                      </ul>
                    </div>
                  </div>
                  <div>
                    <img
                      src="https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                      alt="Festival celebration"
                      className="w-full h-64 object-cover rounded-lg"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Previous sections remain unchanged */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold mb-12 text-center">Essential Travel Information</h2>
          
          {/* Cultural Section */}
          <div className="mb-16">
            <div className="flex items-center gap-4 mb-6">
              <ScrollText className="w-8 h-8 text-blue-600" />
              <h3 className="text-2xl font-semibold">Cultural Awareness</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <img 
                  src="https://images.unsplash.com/photo-1523059623039-a9ed027e7fad?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Cultural traditions" 
                  className="rounded-lg mb-4"
                />
                <h4 className="text-xl font-semibold mb-2">Local Customs</h4>
                <p className="text-gray-600">Learn about greeting customs, dining etiquette, and appropriate dress codes in different cultures.</p>
              </div>
              <div>
                <img 
                  src="https://images.unsplash.com/photo-1552334823-ca7f70385fb3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Religious sites" 
                  className="rounded-lg mb-4"
                />
                <h4 className="text-xl font-semibold mb-2">Religious Practices</h4>
                <p className="text-gray-600">Understand religious customs and protocols when visiting sacred sites and during religious festivals.</p>
              </div>
            </div>
          </div>

          {/* Health Section */}
          <div className="mb-16">
            <div className="flex items-center gap-4 mb-6">
              <Heart className="w-8 h-8 text-red-600" />
              <h3 className="text-2xl font-semibold">Health and Safety</h3>
            </div>
            <div className="bg-red-50 p-6 rounded-lg mb-8">
              <h4 className="text-xl font-semibold mb-4">Essential Health Tips</h4>
              <ul className="grid md:grid-cols-2 gap-4">
                <li className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-red-600" />
                  Research local healthcare facilities
                </li>
                <li className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-red-600" />
                  Check vaccination requirements
                </li>
                <li className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-red-600" />
                  Carry basic medical supplies
                </li>
                <li className="flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-red-600" />
                  Get travel insurance
                </li>
              </ul>
            </div>
          </div>

          {/* Scam Prevention Section */}
          <div>
            <div className="flex items-center gap-4 mb-6">
              <AlertTriangle className="w-8 h-8 text-yellow-600" />
              <h3 className="text-2xl font-semibold">Common Scams to Avoid</h3>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="border border-yellow-200 p-6 rounded-lg bg-yellow-50">
                <h4 className="font-semibold mb-2">Transportation Scams</h4>
                <p className="text-gray-600">Be aware of unlicensed taxis and inflated fares. Always use official transportation services.</p>
              </div>
              <div className="border border-yellow-200 p-6 rounded-lg bg-yellow-50">
                <h4 className="font-semibold mb-2">Tourist Attractions</h4>
                <p className="text-gray-600">Watch out for fake tickets and unauthorized guides at popular tourist sites.</p>
              </div>
              <div className="border border-yellow-200 p-6 rounded-lg bg-yellow-50">
                <h4 className="font-semibold mb-2">Money Exchange</h4>
                <p className="text-gray-600">Use official exchange offices and be cautious of street money changers.</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">About Us</h3>
              <p className="text-gray-400">Dedicated to promoting safe and culturally aware tourism through education and information.</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Cultural Guidelines</li>
                <li>Health Resources</li>
                <li>Safety Tips</li>
                <li>Emergency Contacts</li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">Contact</h3>
              <p className="text-gray-400">For more information and support, reach out to our team.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;